package ChatBotAndTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.namefind.TokenNameFinderModel;
import opennlp.tools.stemmer.PorterStemmer;
import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;
import opennlp.tools.util.Span;

public class OpenNLPTest {

	public static void main(String[] args) throws IOException {
		String path = new File("src/Resources/opennlp-en-ud-ewt-tokens-1.0-1.9.3.bin").getAbsolutePath();
		
		InputStream modelIn = new FileInputStream(path);
		TokenizerModel model = new TokenizerModel(modelIn);
		if (modelIn != null) {
			try {
				modelIn.close();
			} 
			catch (IOException e) {}
		}
		TokenizerME tokenizer = new TokenizerME(model);
		String tokens[] = tokenizer.tokenize("Pierre Volkin is 61 years old.");
		double tokenProbs[] = tokenizer.getTokenProbabilities();
		for(int i = 0; i < tokens.length; i++) {
			System.out.println(tokens[i]);
		}
		
		String pathNameFinder = new File("src/Resources/en-ner-person.bin").getAbsolutePath();
		InputStream modelInNameFinder = new FileInputStream(pathNameFinder);
		TokenNameFinderModel t = new TokenNameFinderModel(modelInNameFinder);
		NameFinderME nameFinder = new NameFinderME(t);
		Span nameStrings[] = nameFinder.find(tokens);
		for (int i = 0; i < nameStrings.length; i++) {
			System.out.println(nameStrings[i]);
		}
	}

}
