package ChatBotAndTest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;


import Jwiki.Jwiki;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

public class GreetTest {

	public static void main(String[] args) throws IOException {

		System.out.println("Hello and welcome to our Chat bot concerning mental health.");
		ThreadSleep(2000);
		System.out.println("If you would, please enter a little bit about yourself, so that we may get to know you better.");
		Scanner input = new Scanner(System.in);
		String patientInformation = input.nextLine();
		System.out.println("And finally, please enter your name or username: ");
		String username = input.nextLine();
		username.trim();
		ChatBot chat = new ChatBot();
		chat.Greet(username, input, Tokenizing(patientInformation));
		input.close();
		
		
		
	}

	// Suspends the thread to give the illusion that the machine is typing out a response.
	public static void ThreadSleep(int milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static String translate(String langFrom, String langTo, String text) throws IOException {
        String urlStr = "https://script.google.com/macros/s/AKfycbyl2YVijacbt1DgzOtg7Qo6iay7_qq0bkQewXkVTWSqA2PSGifltnay9Pu9pMeVMyMf2A/exec" +
                "?q=" + URLEncoder.encode(text, "UTF-8") +
                "&target=" + langTo +
                "&source=" + langFrom;
        URL url = new URL(urlStr);
        StringBuilder response = new StringBuilder();
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        return response.toString();
    }
	
	public static String[] Tokenizing(String patientInfo) throws IOException {
		String path = new File("Resources/opennlp-en-ud-ewt-tokens-1.0-1.9.3.bin").getAbsolutePath();
		
		InputStream modelIn = new FileInputStream(path);
		TokenizerModel model = new TokenizerModel(modelIn);
		if (modelIn != null) {
			try {
				modelIn.close();
			} 
			catch (IOException e) {}
		}
		TokenizerME tokenizer = new TokenizerME(model);
		String tokens[] = tokenizer.tokenize(patientInfo);
		return tokens;
	}
		
}

