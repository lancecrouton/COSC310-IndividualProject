package Testing;
import org.junit.*;
import static org.junit.Assert.*;

import java.io.IOException;

import ChatBotAndTest.GreetTest;

public class JUnitTest {

	@Test
    public void tokenizingTest1() throws IOException {
        GreetTest ob = new GreetTest();
        String[] arr = {"Hi", "my", "name", "is", "Ishaan"};
        assertEquals(arr, ob.Tokenizing("Hi my name is Ishaan"));
    }

    @Test
    public void tokenizingTest2() throws IOException {
        GreetTest ob = new GreetTest();
        assertNotNull(ob.Tokenizing("This is a sentence"));
    }

    @Test
    public void tokenizingTest3() throws IOException {
        GreetTest ob = new GreetTest();
        String[] arr = {"How", "is", "it", "going"};
        assertFalse(arr != ob.Tokenizing("How is it going"));
    }
}
